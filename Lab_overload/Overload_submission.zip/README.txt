Name: Christian Prather
Great lab, would like to have spent a little more time explaining friend prototypes in
class however.