Name:
Christian Prather

Estimated time of completion:
4 hours

Additional Notes:
I utilized the c++ standard library documentation to understand more about application of
stacks and ques. I also know my logic checking could be split into functions and made far more efficient so
I am not happy with how it sits now but I had to prioritize time. The overall step function and
classes could also be templated to offer even more efficiency.