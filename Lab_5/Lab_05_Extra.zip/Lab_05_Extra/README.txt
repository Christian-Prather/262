I added logic to allow for random selection off all three RGB colors meaning the box could be literally any shade of any color at any combination.
I am willing to have it shared if wanted,
Christian Prather