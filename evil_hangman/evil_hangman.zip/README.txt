Name: Christian Prather
Challenges: I had a poor time management system on this project and it cost me. I had to end up filing for an extesion. Program wise the hurdles I had of variable access were
            all solved by using private variables with getters/setter
I really liked the utilization of the class framework and the use case of needing a map.
I spent about 5 hours on this project