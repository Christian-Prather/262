Christian Prather
Aprox time to complete: ~ 6 hours

I think the word map example has a problem as in the instructions the word moon is not used as a key this will cause a problem when
generating the sentence if this word is selected and then tried to use, to solve this I did a check for if I got to the end and didnt find
a ' ' at that point I added a key value of the last word (key) in the test and the first (value)