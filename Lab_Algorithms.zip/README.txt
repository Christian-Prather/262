Name: Christian Prather
Algorithm: Egyptian Multiplication
Notes: The algorithm is broken down into multiple function calls, printColumns handles formatting and printing the elements, multiplication handles the actual logic and math, and
        add handles the summing of the results
